# Advanced Voxel Multiplayer Server — Phase 1

This server implements the first real multiplayer layer:

- WebSocket connection
- rooms
- server-generated player IDs
- fixed 20 tick/s server simulation
- server-authoritative player movement state
- input validation/clamping
- player snapshots at 20/s
- remote-player interpolation on the client
- reconnect/heartbeat on the client
- disconnect notifications
- room capacity limit

No Web Worker is used.

## Run

```bash
npm install
npm start
```

The browser client connects to:

- HTTPS page: `wss://HOST:PORT`
- HTTP/local page: `ws://HOST:PORT`

Optional client variables before `game.js`:

```js
window.AV_MULTIPLAYER_URL = "ws://192.168.x.x:8080";
window.AV_MULTIPLAYER_ROOM = "room1";
```

## Current boundary

The server is authoritative for player input/state in this phase, but it does not yet contain the voxel collision grid, persistent world save, inventory authority, or entity simulation. Those are separate phases and must not be faked by trusting client state.
