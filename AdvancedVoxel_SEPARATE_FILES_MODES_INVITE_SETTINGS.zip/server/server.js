import { WebSocketServer } from "ws";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { ITEM_MAX_STACK, VALID_ITEM_IDS } from "./itemRegistry.js";

const PORT = Number(process.env.PORT || 8080);
const TICK_RATE = 20;
const DT = 1 / TICK_RATE;
const MAX_INPUT = 1;
const MAX_SPEED = 7.5;
const ACCEL = 28;
const FRICTION = 18;
const GRAVITY = 20;
const JUMP_SPEED = 7;
const MAX_Y = 63;
const MIN_Y = 0;
const MAX_PLAYERS_PER_ROOM = 32;
const PLAYER_HALF = 0.18;
const PLAYER_HEIGHT = 1.8;
const STEP_HEIGHT = 0.55;
const CHUNK_SIZE = 32;
const WORLD_HEIGHT = 64;
const MAX_INTERACTION_DISTANCE = 13.0;
const MAX_COMBAT_DISTANCE = 3.25;
const ATTACK_COOLDOWN = 0.55;
const DEFAULT_PLAYER_HP = 60;
const VALID_MODES = new Set(["survival","free","explore","observer"]);
const DEFAULT_PERMISSIONS = {break:true,place:true,combat:true,pickup:true,use:true,chat:true};
function normalizeMode(v){const m=String(v||"survival").toLowerCase();return VALID_MODES.has(m)?m:"survival";}
function cleanPermissions(p){const out={};for(const k of Object.keys(DEFAULT_PERMISSIONS))out[k]=p?.[k]!==false;return out;}
function makeInviteCode(){const chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let code="";do{code="";for(let i=0;i<6;i++)code+=chars[Math.floor(Math.random()*chars.length)];}while(inviteRooms.has(code));return code;}

const MOB_TICK_RANGE = 180;
const MOB_MAX_COUNT = 8;
const MOB_SPAWN_MIN = 72;
const MOB_SPAWN_MAX = 128;
const PROJECTILE_SPEED = 9;
const SAVE_DIR = path.join(process.cwd(), "save");
const SAVE_FILE = path.join(SAVE_DIR, "rooms.json");
const VALID_BLOCKS = new Set([0,1,2,3,4,5,6,7,8,9]);
const INVENTORY_SLOTS = 30;
const HOTBAR_SLOTS = 12;
const EQUIPMENT_SLOTS = ["head","chest","legs","feet","shield","weapon"];
const DEFAULT_INVENTORY = {quy_tinh_sword:1,titan_drill_1:1,oxygen_tank:3,components:6,titanite_blood:6,revive_decoy:1,titan_training_dummy:1};
const WEAPON_DAMAGE = { quy_tinh_sword: 8, war_sword_01:8, war_sword_02:10, war_sword_03:11, war_sword_04:12, war_sword_05:13, war_sword_06:14, war_sword_07:16, war_sword_08:13, war_sword_09:18, war_sword_10:15, war_sword_11:16, war_sword_12:17, war_sword_13:18, war_sword_14:20, war_sword_15:17, war_sword_16:21, war_sword_17:19, war_sword_18:18, war_sword_19:20, war_sword_20:21, war_sword_21:19, war_sword_22:20, war_sword_23:22, war_sword_24:20, war_sword_25:23, war_sword_26:24, war_sword_27:22, war_sword_28:25, war_sword_29:23, war_sword_30:26, war_sword_31:25, war_sword_32:24, war_sword_33:27, war_sword_34:28, war_sword_35:30, war_sword_36:29, war_sword_37:31, war_sword_38:30, war_sword_39:32, war_sword_40:34, war_sword_41:33, war_sword_42:30, war_sword_43:28, war_sword_44:35, war_sword_45:31, war_sword_46:38, war_sword_47:36, war_sword_48:40, war_sword_49:32, war_sword_50:37, war_sword_51:39, war_sword_52:42, war_sword_53:44, war_sword_54:46, war_sword_55:48, war_sword_56:50, war_sword_57:52, war_sword_58:55, war_sword_59:58, war_sword_60:60, war_sword_61:63, war_sword_62:66, war_sword_63:70, war_sword_64:75 };
const ARMOR_DEFENSE = { war_armor_01_helmet:2, war_armor_01_chestplate:3, war_armor_01_leggings:2, war_armor_01_boots:1 };
for (let i=1;i<=16;i++){ const d=[8,12,13,14,15,17,18,16,20,19,21,22,25,28,32,40][i-1]; ARMOR_DEFENSE[`war_armor_${String(i).padStart(2,"0")}_helmet`]=Math.floor(d*0.22); ARMOR_DEFENSE[`war_armor_${String(i).padStart(2,"0")}_chestplate`]=Math.floor(d*0.36); ARMOR_DEFENSE[`war_armor_${String(i).padStart(2,"0")}_leggings`]=Math.floor(d*0.26); ARMOR_DEFENSE[`war_armor_${String(i).padStart(2,"0")}_boots`]=Math.max(1,Math.floor(d*0.16)); }
function getPlayerDefense(c){ return Object.values(c.inventory.equipment||{}).reduce((n,id)=>n+(ARMOR_DEFENSE[id]||0),0); }
function getSelectedWeapon(c,requested){ const id=String(requested||""); const slot=c.inventory.selectedSlot; const hot=c.inventory.hotbar[slot]; if(id && id===hot && hasItem(c.inventory,id,1) && WEAPON_DAMAGE[id]) return id; if(id && id===c.inventory.equipment.weapon && hasItem(c.inventory,id,1) && WEAPON_DAMAGE[id]) return id; return null; }
function handleAttackRequest(c,p){
  if(!c.room) return; const requestId=p?.requestId||null, targetId=String(p?.targetId||""), weaponId=getSelectedWeapon(c,p?.weaponId);
  if(!weaponId) return send(c.ws,"combatReject",{requestId,reason:"INVALID_WEAPON"});
  const target=[...c.room.players].find(x=>x.id===targetId); if(!target||target===c) return send(c.ws,"combatReject",{requestId,reason:"INVALID_TARGET"});
  if(target.dimension!==c.dimension) return send(c.ws,"combatReject",{requestId,reason:"WRONG_DIMENSION"});
  if(target.id&&c.room.pvp===false)return send(c.ws,"combatReject",{requestId,reason:"PVP_DISABLED"});
  const distance=Math.hypot(target.x-c.x,(target.y+0.9)-(c.y+0.9),target.z-c.z); if(distance>MAX_COMBAT_DISTANCE) return send(c.ws,"combatReject",{requestId,reason:"OUT_OF_REACH"});
  const t=now(); if(t-c.lastAttack<ATTACK_COOLDOWN*1000) return send(c.ws,"combatReject",{requestId,reason:"COOLDOWN"}); c.lastAttack=t;
  const raw=WEAPON_DAMAGE[weaponId]||2, defense=getPlayerDefense(target), final=Math.max(1,raw*(100/(100+defense))); target.hp=Math.max(0,target.hp-final);
  const hit={requestId,attackerId:c.id,targetId:target.id,weaponId,rawDamage:raw,defense,damage:final,targetHp:target.hp,serverTime:t};
  broadcast(c.room,"combatHit",hit);
  if(target.hp<=0){ target.hp=DEFAULT_PLAYER_HP; target.x=16; target.y=20.5; target.z=16; target.vx=target.vy=target.vz=0; target.grounded=false; broadcast(c.room,"playerRespawn",{id:target.id,reason:"combat",serverTime:t}); }
}

const DEFAULT_HOTBAR = ["quy_tinh_sword","titan_drill_1","titan_drill_2","titan_drill_3","titan_drill_4","oxygen_tank","revive_charm","revive_decoy","titan_training_dummy","titanite_blood","dark_matter","components"];



function nextEntity(room,prefix){ return `${prefix}_${room.nextEntityId++}`; }
function distance3(a,b){ return Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z); }
function mobState(m){ return {id:m.id,type:m.type,x:m.x,y:m.y,z:m.z,hp:m.hp,maxHp:m.maxHp,targetId:m.targetId||null,dimension:m.dimension,dead:!!m.dead}; }
function projectileState(p){ return {id:p.id,type:p.type,x:p.x,y:p.y,z:p.z,vx:p.vx,vy:p.vy,vz:p.vz,color:p.color||0xffffff,damage:p.damage||0,ownerId:p.ownerId||null,targetId:p.targetId||null}; }
function mobBroadcast(room){ sendMany(room,"mobSnapshot",{serverTime:now(),mobs:[...room.mobs.values()].filter(m=>!m.dead).map(mobState)}); }
function projectileBroadcast(room){ sendMany(room,"projectileSnapshot",{serverTime:now(),projectiles:[...room.projectiles.values()].filter(p=>!p.dead).map(projectileState)}); }
function sendMany(room,type,payload){ for(const c of room.players) send(c.ws,type,payload); }
function getTargetEntity(room,id){
  const p=[...room.players].find(x=>x.id===id); if(p) return {kind:"player",ref:p};
  const m=room.mobs.get(String(id)); if(m&&!m.dead) return {kind:"mob",ref:m};
  return null;
}
function damagePlayer(room,target,amount,source){
  if(!target||target.hp<=0)return false; if(target.mode==="free"||target.mode==="observer")return false;
  const defense=getPlayerDefense(target); const final=Math.max(1,Number(amount||0)*100/(100+defense));
  target.hp=Math.max(0,target.hp-final);
  sendMany(room,"damageEvent",{targetId:target.id,sourceId:source?.id||null,sourceType:source?.type||"unknown",damage:final,hp:target.hp});
  if(target.hp<=0){ target.hp=DEFAULT_PLAYER_HP; target.x=16;target.y=20.5;target.z=16;target.vx=target.vy=target.vz=0;target.grounded=false;sendMany(room,"playerRespawn",{id:target.id,reason:"damage",serverTime:now()}); }
  return true;
}
function damageMob(room,mob,amount,source){
  if(!mob||mob.dead)return false; mob.hp=Math.max(0,mob.hp-Number(amount||0));
  sendMany(room,"mobDamage",{mobId:mob.id,sourceId:source?.id||null,damage:Number(amount||0),hp:mob.hp,maxHp:mob.maxHp});
  if(mob.hp<=0){mob.dead=true;sendMany(room,"mobDeath",{mobId:mob.id,type:mob.type,x:mob.x,y:mob.y,z:mob.z,sourceId:source?.id||null});spawnDrop(room,mob.x,mob.y,mob.z,mob.type==="warden"?"titan_guard_crystal":"dark_matter",1,mob.dimension);}
  return true;
}
function spawnMob(room,type,x,z,dimension="main"){
  const y=dimension==="war"?Math.max(1,terrainHeight(x,z)+0.02):terrainHeight(x,z)+0.02;
  const spec=type==="warden"?{hp:100,speed:1.5}:{hp:80,speed:1.8};
  const m={id:nextEntity(room,"mob"),type,x,y,z,hp:spec.hp,maxHp:spec.hp,speed:spec.speed,dimension,targetId:null,attackCd:0,rangedCd:0,dead:false};
  room.mobs.set(m.id,m); return m;
}
function handleDropPickup(c,p){if(!c.room)return;if(c.permissions.pickup===false||c.mode==="observer")return;const d=c.room.drops.get(String(p?.dropId||""));if(!d||d.dead||d.dimension!==c.dimension)return; if(Math.hypot(c.x-d.x,c.y-d.y,c.z-d.z)>3)return; if(addItem(c.inventory,d.itemId,d.count)){d.dead=true;c.room.drops.delete(d.id);invChanged(c);sendMany(c.room,"dropDelta",{action:"remove",dropId:d.id});}}
function spawnDrop(room,x,y,z,itemId,count,dimension="main"){
  if(!VALID_ITEM_IDS.has(itemId))return null; const d={id:nextEntity(room,"drop"),x,y,z,itemId,count,dimension,dead:false};room.drops.set(d.id,d);sendMany(room,"dropDelta",{action:"spawn",drop:d});return d;}
function handleMobAttack(c,p){
  if(!c.room)return; if(c.mode==="observer"||c.permissions.combat===false)return send(c.ws,"combatReject",{requestId:p?.requestId||null,reason:"NO_COMBAT_PERMISSION"}); const targetId=String(p?.targetId||""); const ent=getTargetEntity(c.room,targetId); if(!ent)return send(c.ws,"combatReject",{requestId:p?.requestId||null,reason:"INVALID_TARGET"});
  const weaponId=getSelectedWeapon(c,p?.weaponId); if(!weaponId)return send(c.ws,"combatReject",{requestId:p?.requestId||null,reason:"INVALID_WEAPON"});
  const m=ent.kind==="mob"?ent.ref:null; if(!m)return handleAttackRequest(c,p);
  if(m.dimension!==c.dimension)return send(c.ws,"combatReject",{requestId:p?.requestId||null,reason:"WRONG_DIMENSION"});
  if(distance3(c,m)>MAX_COMBAT_DISTANCE)return send(c.ws,"combatReject",{requestId:p?.requestId||null,reason:"OUT_OF_REACH"});
  const t=now();if(t-c.lastAttack<ATTACK_COOLDOWN*1000)return send(c.ws,"combatReject",{requestId:p?.requestId||null,reason:"COOLDOWN"});c.lastAttack=t;
  const raw=WEAPON_DAMAGE[weaponId]||2; damageMob(c.room,m,raw,{id:c.id,type:"player",weaponId});send(c.ws,"combatHit",{requestId:p?.requestId||null,attackerId:c.id,targetId:m.id,weaponId,rawDamage:raw,damage:raw,targetHp:m.hp,serverTime:t});
  // Warden aggro propagation: nearby wardens join if one is hit.
  if(m.type==="warden")for(const o of c.room.mobs.values())if(!o.dead&&o.type==="warden"&&distance3(o,m)<=20)o.targetId=c.id;
}
function handleSkillRequest(c,p){
  if(!c.room)return; const skillId=String(p?.skillId||""); const idx=Math.max(1,Math.min(20,Number(skillId.replace(/\D/g,""))||0)); if(!idx)return send(c.ws,"skillReject",{requestId:p?.requestId||null,reason:"INVALID_SKILL"});
  const defs=[null,{count:144,damage:24,range:40,duration:20,cooldown:60},{count:0,damage:0,range:0,duration:0,cooldown:0},{count:36,damage:12,range:40,duration:6,cooldown:25},{count:1,damage:20,range:40,duration:1,cooldown:8},{count:18,damage:10,range:8,duration:15,cooldown:30},{count:12,damage:10,range:40,duration:1,cooldown:20},{count:24,damage:14,range:40,duration:1,cooldown:35},{count:0,damage:6,range:12,duration:10,cooldown:24},{count:5,damage:9,range:40,duration:2,cooldown:15},{count:0,damage:10,range:6,duration:10,cooldown:40},{count:1,damage:30,range:40,duration:2,cooldown:45},{count:18,damage:12,range:6,duration:10,cooldown:35},{count:1,damage:18,range:40,duration:1,cooldown:30},{count:12,damage:16,range:8,duration:8,cooldown:32},{count:1,damage:50,range:40,duration:6,cooldown:45},{count:32,damage:18,range:40,duration:8,cooldown:40},{count:1,damage:0,range:40,duration:1,cooldown:28},{count:8,damage:12,range:20,duration:6,cooldown:30},{count:24,damage:15,range:20,duration:8,cooldown:38},{count:144,damage:35,range:40,duration:4,cooldown:90}];
  const d=defs[idx]; if(!c.skillCooldowns)c.skillCooldowns={}; const t=now(); if((c.skillCooldowns[idx]||0)>t)return send(c.ws,"skillReject",{requestId:p?.requestId||null,reason:"COOLDOWN"});
  const targetId=String(p?.targetId||""); const ent=targetId?getTargetEntity(c.room,targetId):null; if(ent&&distance3(c,ent.ref)>d.range)return send(c.ws,"skillReject",{requestId:p?.requestId||null,reason:"OUT_OF_RANGE"});
  c.skillCooldowns[idx]=t+d.cooldown*1000; const id=nextEntity(c.room,"skill"); const inst={id,ownerId:c.id,skillId:`skill_${String(idx).padStart(2,"0")}`,targetId:ent?.ref?.id||null,damage:d.damage,count:d.count,remainingHits:Math.max(1,d.count||1),duration:d.duration*1000,created:t,nextHit:t,dimension:c.dimension,dead:false};
  if(idx===2){ send(c.ws,"skillAccepted",{requestId:p?.requestId||null,skillId:inst.skillId,serverTime:t}); return; }
  if(idx===17 && ent){ const old={x:c.x,y:c.y,z:c.z}; c.x=ent.ref.x;c.y=ent.ref.y;c.z=ent.ref.z; if(ent.kind==="player"){ent.ref.x=old.x;ent.ref.y=old.y;ent.ref.z=old.z;} }
  c.room.skills.set(id,inst); sendMany(c.room,"skillCast",{id,ownerId:c.id,skillId:inst.skillId,targetId:inst.targetId,serverTime:t,dimension:c.dimension}); send(c.ws,"skillAccepted",{requestId:p?.requestId||null,skillId:inst.skillId,serverTime:t});
}
function tickSkills(room,t){
  for(const [id,s] of room.skills){if(s.dead){room.skills.delete(id);continue;} const end=s.created+s.duration; if(t>=end||s.remainingHits<=0){s.dead=true;room.skills.delete(id);continue;} const interval=Math.max(40,s.duration/Math.max(1,s.count||1)); if(t<s.nextHit)continue; s.nextHit=t+interval; const ent=s.targetId?getTargetEntity(room,s.targetId):null; if(!ent)continue; if(distance3(room.players.has(ent.ref)?ent.ref:{x:0,y:0,z:0},ent.ref)>1000)continue; damageTargetEntity(room,ent,s.damage,{id:s.ownerId,type:"skill",skillId:s.skillId}); s.remainingHits--; }
}
function damageTargetEntity(room,ent,amount,source){ if(ent.kind==="player")return damagePlayer(room,ent.ref,amount,source); return damageMob(room,ent.ref,amount,source); }
function spawnMobProjectile(room,m, target, color, damage){ const dx=target.x-m.x,dy=(target.y+1)-(m.y+1),dz=target.z-m.z;const len=Math.hypot(dx,dy,dz)||1;const p={id:nextEntity(room,"proj"),type:m.type==="warden"?"warden_orb":"ravage_orb",x:m.x,y:m.y+1.5,z:m.z,vx:dx/len*PROJECTILE_SPEED,vy:dy/len*PROJECTILE_SPEED,vz:dz/len*PROJECTILE_SPEED,color,damage,ownerId:m.id,targetId:target.id||null,dimension:m.dimension,life:6,dead:false};room.projectiles.set(p.id,p);}
function tickMobs(room){
  for(const m of room.mobs.values()){if(m.dead)continue;m.attackCd-=DT;m.rangedCd-=DT;let target=null,best=Infinity;
    if(m.type==="ravage")for(const p of room.players){if(p.dimension!==m.dimension)continue;const d=distance3(p,m);if(d<best&&d<30){best=d;target=p;}}
    for(const o of room.mobs.values())if(!o.dead&&o!==m&&o.dimension===m.dimension&&o.type!==m.type){const d=distance3(o,m);if(d<best&&d<(m.type==="warden"?14:12)){best=d;target=o;}}
    if(target){m.targetId=target.id;const dx=target.x-m.x,dz=target.z-m.z,len=Math.hypot(dx,dz)||1;if(best> (m.type==="warden"?5.5:4.5)){m.x+=dx/len*m.speed*DT;m.z+=dz/len*m.speed*DT;m.y=terrainHeight(m.x,m.z)+0.02;}else if(m.attackCd<=0){m.attackCd=m.type==="warden"?1.2:1.0;const dmg=m.type==="warden"?6:8;if(target.id?.startsWith("mob_")){damageMob(room,target,dmg,m);}else damagePlayer(room,target,dmg,m);}}
    if(target&&m.rangedCd<=0&&best>6&&best<30){m.rangedCd=m.type==="warden"?2.2:2.0;spawnMobProjectile(room,m,target,m.type==="warden"?0x39a9ff:0x090909,4);}
  }
  // spawn outside 2 chunks, capped for mobile.
  if(room.players.size){const ps=[...room.players];for(let tries=0;tries<2&&room.mobs.size<MOB_MAX_COUNT;tries++){const p=ps[Math.floor(Math.random()*ps.length)];const a=Math.random()*Math.PI*2,d=MOB_SPAWN_MIN+Math.random()*(MOB_SPAWN_MAX-MOB_SPAWN_MIN);const x=p.x+Math.cos(a)*d,z=p.z+Math.sin(a)*d;const type=Math.random()<0.68?"warden":"ravage";spawnMob(room,type,x,z,p.dimension);}}
}
function tickProjectiles(room){for(const p of room.projectiles.values()){if(p.dead){room.projectiles.delete(p.id);continue;}p.x+=p.vx*DT;p.y+=p.vy*DT;p.z+=p.vz*DT;p.life-=DT;if(p.life<=0){p.dead=true;continue;}for(const target of room.players){if(target.id===p.ownerId||target.dimension!==p.dimension)continue;if(Math.hypot(target.x-p.x,(target.y+0.9)-p.y,target.z-p.z)<0.9){damagePlayer(room,target,p.damage,{id:p.ownerId,type:p.type});p.dead=true;break;}}for(const m of room.mobs.values())if(!p.dead&&!m.dead&&m.id!==p.ownerId&&m.dimension===p.dimension&&Math.hypot(m.x-p.x,(m.y+0.8)-p.y,m.z-p.z)<1){damageMob(room,m,p.damage,{id:p.ownerId,type:p.type});p.dead=true;}}
}
function loadPersistence(){try{if(!fs.existsSync(SAVE_FILE))return {};return JSON.parse(fs.readFileSync(SAVE_FILE,"utf8"));}catch{return {};}}
const persisted=loadPersistence();
if(!persisted.players) persisted.players={};
function savePersistence(){try{fs.mkdirSync(SAVE_DIR,{recursive:true});const out={rooms:{},players:{}};for(const [name,r] of rooms){out.rooms[name]={revision:r.world.revision,edits:[...r.world.edits],savedAt:Date.now(),inviteCode:r.inviteCode||null,worldName:r.worldName||r.name,defaultMode:r.defaultMode||"survival",defaultPermissions:r.defaultPermissions||DEFAULT_PERMISSIONS,pvp:r.pvp!==false}; for(const c of r.players) if(c.playerKey) out.players[c.playerKey]={inventory:c.inventory,inventoryRevision:c.inventoryRevision};}fs.writeFileSync(SAVE_FILE,JSON.stringify(out));}catch(e){console.error("save failed",e.message);}}
setInterval(savePersistence,15000);
process.on("SIGINT",()=>{savePersistence();process.exit(0);});

const wss = new WebSocketServer({ port: PORT, maxPayload: 16 * 1024 });
const rooms = new Map();
const inviteRooms = new Map();
let serverTick = 0;

const now = () => Date.now();
const finite = (v, fallback = 0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const int = v => Math.trunc(finite(v));
const chunkKey = (cx, cz) => `${cx},${cz}`;
const editKey = (x,y,z) => `${x},${y},${z}`;
function localCoord(v) { const r = v % CHUNK_SIZE; return r < 0 ? r + CHUNK_SIZE : r; }
function worldToChunk(x,z) { return { cx: Math.floor(x / CHUNK_SIZE), cz: Math.floor(z / CHUNK_SIZE) }; }
function send(ws, type, payload = {}) {
  if (ws.readyState !== 1) return;
  ws.send(JSON.stringify({ v: 3, type, t: now(), payload }));
}
function broadcast(room, type, payload, except = null) {
  for (const c of room.players) if (c !== except) send(c.ws, type, payload);
}

function hash3i(x,y,z) {
  let n = Math.imul(x|0,374761393);
  n = Math.imul(n ^ (n >>> 13),668265263);
  n ^= Math.imul(y|0,1442695041);
  n = Math.imul(n ^ (n >>> 16),2246822519);
  n ^= Math.imul(z|0,3266489917);
  n = Math.imul(n ^ (n >>> 13),1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
}
function fade(t) { return t*t*(3-2*t); }
function valueNoise3(x,y,z,scale) {
  const sx=x/scale, sy=y/scale, sz=z/scale;
  const x0=Math.floor(sx), y0=Math.floor(sy), z0=Math.floor(sz);
  const tx=fade(sx-x0), ty=fade(sy-y0), tz=fade(sz-z0);
  const c000=hash3i(x0,y0,z0), c100=hash3i(x0+1,y0,z0), c010=hash3i(x0,y0+1,z0), c110=hash3i(x0+1,y0+1,z0);
  const c001=hash3i(x0,y0,z0+1), c101=hash3i(x0+1,y0,z0+1), c011=hash3i(x0,y0+1,z0+1), c111=hash3i(x0+1,y0+1,z0+1);
  const x00=c000+(c100-c000)*tx, x10=c010+(c110-c010)*tx, x01=c001+(c101-c001)*tx, x11=c011+(c111-c011)*tx;
  const y0v=x00+(x10-x00)*ty, y1v=x01+(x11-x01)*ty;
  return y0v+(y1v-y0v)*tz;
}
function caveNoise(wx,y,wz) {
  return {
    broad:valueNoise3(wx,y*0.62,wz,22),
    detail:valueNoise3(wx*1.35,y*0.82,wz*1.35,11),
    tunnel:valueNoise3(wx*0.72+37,y*1.15-19,wz*0.72-11,15)
  };
}
function terrainHeight(x,z) {
  return Math.max(8, Math.floor(20 + Math.sin(x*0.045)*4 + Math.cos(z*0.035)*4 + Math.sin((x+z)*0.018)*5));
}
function baseBlock(x,y,z,dimension="main") {
  if (y < 0 || y >= WORLD_HEIGHT) return 0;
  if (dimension === "serpent_void") dimension = "war";
  if (dimension === "war") {
    // Original War World baseline: rolling stone islands with five tree variants.
    const h = Math.max(10, Math.floor(18 + Math.sin(x*0.052)*4 + Math.cos(z*0.041)*4 + Math.sin((x-z)*0.021)*3));
    if (y > h) return 0;
    let b = y <= 1 ? 5 : y <= 7 ? 4 : y <= 13 ? 3 : 1;
    // sparse battlefield pillars / ruins
    const pillar = ((Math.abs((x*31+z*17)%97))===0) && y <= h+7;
    if (pillar && y>h) b=2;
    // original tree blocks represented by existing wood-like ids are intentionally omitted from block registry; foliage remains client-side.
    return b;
  }
  const surface=terrainHeight(x,z);
  if (y > surface) return 0;
  let block = y<=1 ? 5 : y<=7 ? 4 : y<=15 ? 3 : y<=23 ? 2 : 1;
  if (y >= surface-1) block=1;
  const spawnPad=(Math.abs(x-16)<=2 && Math.abs(z-16)<=2);
  if (!spawnPad && y>4 && y<surface-7) {
    const cave=caveNoise(x,y,z);
    const depth=Math.max(0,Math.min(1,(surface-y-7)/16));
    if (cave.broad > 0.82-depth*0.06 && cave.detail > 0.58-depth*0.04 && cave.tunnel > 0.50) block=0;
  }
  if (block!==0 && y>=8 && y<=surface-4 && valueNoise3(x,y,z,11)>0.995) block=9;
  return block;
}

function getAuthoritativeBlock(room,x,y,z,dimension) {
  const k=editKey(x,y,z);
  if (room.world.edits.has(k)) return room.world.edits.get(k);
  return baseBlock(x,y,z,dimension);
}
function setAuthoritativeBlock(room,x,y,z,value) {
  room.world.edits.set(editKey(x,y,z),value);
  room.world.revision++;
}
function editsForChunk(room,cx,cz,dimension) {
  const out=[];
  const prefix=[];
  for (const [k,v] of room.world.edits) {
    const [x,y,z]=k.split(',').map(Number);
    if (Math.floor(x/CHUNK_SIZE)===cx && Math.floor(z/CHUNK_SIZE)===cz) out.push({x,y,z,blockId:v});
  }
  return out;
}


function emptySlot(){ return {id:null,count:0}; }
function normalizeSlot(st){
  const id=VALID_ITEM_IDS.has(String(st?.id||""))?String(st.id):null;
  const max=id?(ITEM_MAX_STACK[id]||256):0;
  const count=id?clamp(Math.trunc(finite(st.count)),0,max):0;
  return id&&count>0?{id,count}:emptySlot();
}
function makeInventory(){
  const slots=Array.from({length:INVENTORY_SLOTS},emptySlot);
  let cursor=0;
  for(const [id,count0] of Object.entries(DEFAULT_INVENTORY)){
    if(!VALID_ITEM_IDS.has(id)) continue;
    let count=Math.max(0,Math.trunc(count0)); const max=ITEM_MAX_STACK[id]||256;
    while(count>0 && cursor<INVENTORY_SLOTS){ const take=Math.min(count,max); slots[cursor++]={id,count:take}; count-=take; }
  }
  return {slots,hotbar:DEFAULT_HOTBAR.slice(0,HOTBAR_SLOTS),selectedSlot:0,equipment:{head:null,chest:null,legs:null,feet:null,shield:null,weapon:"quy_tinh_sword"}};
}
function inventoryTotals(inv){ const out={}; for(const st of inv.slots){if(st.id&&st.count>0)out[st.id]=(out[st.id]||0)+st.count;} return out; }
function hasItem(inv,id,count=1){return !!id&&inventoryTotals(inv)[id]>=count;}
function removeItem(inv,id,count){
  let left=Math.max(0,Math.trunc(count)); if(!hasItem(inv,id,left)) return false;
  for(let i=inv.slots.length-1;i>=0&&left>0;i--){const st=inv.slots[i];if(st.id!==id)continue;const take=Math.min(left,st.count);st.count-=take;left-=take;if(st.count<=0)inv.slots[i]=emptySlot();}
  return left===0;
}
function addItem(inv,id,count){
  if(!VALID_ITEM_IDS.has(id)||count<=0)return false; const max=ITEM_MAX_STACK[id]||256; let left=Math.trunc(count);
  for(const st of inv.slots){if(left<=0)break;if(st.id===id&&st.count<max){const add=Math.min(left,max-st.count);st.count+=add;left-=add;}}
  for(let i=0;i<inv.slots.length&&left>0;i++){if(!inv.slots[i].id){const add=Math.min(left,max);inv.slots[i]={id,count:add};left-=add;}}
  return left===0;
}
function inventoryState(c){
  const inv=c.inventory; return {slots:inv.slots.map(normalizeSlot),hotbar:inv.hotbar.slice(0,HOTBAR_SLOTS),selectedSlot:inv.selectedSlot,equipment:{...inv.equipment},totals:inventoryTotals(inv),revision:c.inventoryRevision};
}
function sendInventory(c){send(c.ws,"inventoryState",inventoryState(c));}
function invChanged(c){c.inventoryRevision++;sendInventory(c);}
function inventoryError(c,requestId,reason){send(c.ws,"inventoryReject",{requestId:requestId||null,reason});}
function validSlot(n){return Number.isInteger(Number(n))&&Number(n)>=0&&Number(n)<INVENTORY_SLOTS;}
function handleInventoryRequest(c,p){
  if(!c.room||!p)return; const action=String(p.action||""); const requestId=p.requestId||null; const inv=c.inventory;
  if(action==="move"||action==="swap"){
    const from=Math.trunc(finite(p.from,-1)),to=Math.trunc(finite(p.to,-1)); if(!validSlot(from)||!validSlot(to)||from===to)return inventoryError(c,requestId,"INVALID_SLOT");
    const a=inv.slots[from],b=inv.slots[to];
    if(!a.id||a.count<=0)return inventoryError(c,requestId,"EMPTY_SOURCE");
    if(b.id===a.id){const max=ITEM_MAX_STACK[a.id]||256,add=Math.min(a.count,Math.max(0,max-b.count));b.count+=add;a.count-=add;if(a.count<=0)inv.slots[from]=emptySlot();}
    else {inv.slots[from]=b;inv.slots[to]=a;}
    invChanged(c);return;
  }
  if(action==="split"){
    const from=Math.trunc(finite(p.from,-1));if(!validSlot(from))return inventoryError(c,requestId,"INVALID_SLOT");const st=inv.slots[from];if(!st.id||st.count<2)return inventoryError(c,requestId,"CANNOT_SPLIT");
    const requestedTo=Number(p.to); const to=(Number.isInteger(requestedTo)&&requestedTo>=0)?Math.trunc(requestedTo):inv.slots.findIndex(x=>!x.id); if(!validSlot(to)||to===from||inv.slots[to].id)return inventoryError(c,requestId,"NO_FREE_SLOT");
    const take=Math.max(1,Math.min(st.count-1,Math.trunc(finite(p.amount,Math.ceil(st.count/2)))));inv.slots[to]={id:st.id,count:take};st.count-=take;invChanged(c);return;
  }
  if(action==="takeOne"){
    const from=Math.trunc(finite(p.from,-1));if(!validSlot(from))return inventoryError(c,requestId,"INVALID_SLOT");const st=inv.slots[from];if(!st.id||st.count<1)return inventoryError(c,requestId,"EMPTY_SOURCE");
    const to=inv.slots.findIndex(x=>!x.id);if(to<0)return inventoryError(c,requestId,"NO_FREE_SLOT");inv.slots[to]={id:st.id,count:1};st.count--;if(st.count<=0)inv.slots[from]=emptySlot();invChanged(c);return;
  }
  if(action==="assignHotbar"){
    const slot=Math.trunc(finite(p.slot,-1));const id=String(p.id||"");if(slot<0||slot>=HOTBAR_SLOTS||!VALID_ITEM_IDS.has(id)||!hasItem(inv,id,1))return inventoryError(c,requestId,"INVALID_HOTBAR_ASSIGN");inv.hotbar[slot]=id;inv.selectedSlot=slot;invChanged(c);return;
  }
  if(action==="clearHotbar"){
    const slot=Math.trunc(finite(p.slot,-1));if(slot<0||slot>=HOTBAR_SLOTS)return inventoryError(c,requestId,"INVALID_HOTBAR_SLOT");inv.hotbar[slot]=null;if(inv.selectedSlot===slot)inv.selectedSlot=0;invChanged(c);return;
  }
  if(action==="selectHotbar"){
    const slot=Math.trunc(finite(p.slot,-1));if(slot<0||slot>=HOTBAR_SLOTS)return inventoryError(c,requestId,"INVALID_HOTBAR_SLOT");inv.selectedSlot=slot;invChanged(c);return;
  }
  if(action==="equip"){if(c.permissions.use===false||c.mode==="observer")return inventoryError(c,requestId,"NO_USE_PERMISSION");
    const slot=String(p.slot||"");const id=String(p.id||"");
    const okType=(slot==="head"&&id.includes("_helmet"))||(slot==="chest"&&id.includes("_chestplate"))||(slot==="legs"&&id.includes("_leggings"))||(slot==="feet"&&id.includes("_boots"))||(slot==="shield"&&id.startsWith("war_shield_"))||(slot==="weapon"&&(id==="quy_tinh_sword"||id.startsWith("war_sword_")||id.startsWith("war_axe_")||id.startsWith("war_bow_")));
    if(!EQUIPMENT_SLOTS.includes(slot)||!VALID_ITEM_IDS.has(id)||!okType||!hasItem(inv,id,1))return inventoryError(c,requestId,"INVALID_EQUIPMENT");
    const old=inv.equipment[slot]; if(old&&old!==id&&!addItem(inv,old,1)){return inventoryError(c,requestId,"INVENTORY_FULL");}
    if(!removeItem(inv,id,1))return inventoryError(c,requestId,"ITEM_MISSING"); inv.equipment[slot]=id;invChanged(c);return;
  }
  if(action==="unequip"){if(c.permissions.use===false||c.mode==="observer")return inventoryError(c,requestId,"NO_USE_PERMISSION");
    const slot=String(p.slot||"");if(!EQUIPMENT_SLOTS.includes(slot))return inventoryError(c,requestId,"INVALID_EQUIPMENT");const id=inv.equipment[slot];if(!id)return inventoryError(c,requestId,"EMPTY_EQUIPMENT");if(!addItem(inv,id,1))return inventoryError(c,requestId,"INVENTORY_FULL");inv.equipment[slot]=null;invChanged(c);return;
  }
  if(action==="consume"){if(c.permissions.use===false||c.mode==="observer")return inventoryError(c,requestId,"NO_USE_PERMISSION");
    const id=String(p.id||"");const count=Math.max(1,Math.trunc(finite(p.count,1)));if(!removeItem(inv,id,count))return inventoryError(c,requestId,"ITEM_MISSING");invChanged(c);return;
  }
  if(action==="add"){
    const id=String(p.id||"");const count=Math.max(1,Math.trunc(finite(p.count,1)));if(!addItem(inv,id,count))return inventoryError(c,requestId,"INVENTORY_FULL");invChanged(c);return;
  }
  if(action==="craft"){if(c.permissions.use===false||c.mode==="observer")return inventoryError(c,requestId,"NO_USE_PERMISSION");
    const recipes={crafting_machine:{ingredients:{components:6},output:{id:"crafting_machine",count:1}},space_gate:{ingredients:{dark_matter:4,space_stone:1,titanite_blood:6},output:{id:"space_gate",count:1}}};
    const recipe=recipes[String(p.recipeId||"")];if(!recipe)return inventoryError(c,requestId,"RECIPE_NOT_FOUND");for(const [id,n] of Object.entries(recipe.ingredients))if(!hasItem(inv,id,n))return inventoryError(c,requestId,"MISSING_INGREDIENT");if(!addItem({...inv,slots:inv.slots.map(s=>({...s}))},recipe.output.id,recipe.output.count))return inventoryError(c,requestId,"INVENTORY_FULL");
    for(const [id,n] of Object.entries(recipe.ingredients))removeItem(inv,id,n);if(!addItem(inv,recipe.output.id,recipe.output.count)){for(const [id,n] of Object.entries(recipe.ingredients))addItem(inv,id,n);return inventoryError(c,requestId,"INVENTORY_FULL");}invChanged(c);return;
  }
  inventoryError(c,requestId,"UNKNOWN_ACTION");
}

function state(c) { return { id:c.id,x:c.x,y:c.y,z:c.z,vx:c.vx,vy:c.vy,vz:c.vz,yaw:c.yaw,pitch:c.pitch,hp:c.hp,dimension:c.dimension,grounded:c.grounded,mode:c.mode||"survival",permissions:c.permissions||DEFAULT_PERMISSIONS,isHost:!!c.isHost }; }
function roomSnapshot(room) { return [...room.players].map(state); }
function getRoom(name) {
  let room=rooms.get(name);
  if (!room) { room={name,players:new Set(),createdAt:now(),world:{revision:0,edits:new Map()},mobs:new Map(),projectiles:new Map(),drops:new Map(),skills:new Map(),nextEntityId:1,inviteCode:null,worldName:name,defaultMode:"survival",defaultPermissions:{...DEFAULT_PERMISSIONS},pvp:true}; const saved=persisted?.rooms?.[name]; if(saved?.edits){for(const [k,v] of saved.edits) room.world.edits.set(k,v); room.world.revision=Number(saved.revision)||room.world.edits.size;} if(saved?.inviteCode){room.inviteCode=saved.inviteCode;inviteRooms.set(room.inviteCode,room.name);} room.worldName=saved?.worldName||name;room.defaultMode=normalizeMode(saved?.defaultMode);room.defaultPermissions=cleanPermissions(saved?.defaultPermissions);room.pvp=saved?.pvp!==false; rooms.set(name,room); }
  return room;
}
function leaveRoom(c) {
  if (!c.room) return;
  const room=c.room; room.players.delete(c); c.room=null;
  broadcast(room,"playerLeft",{id:c.id});
  if (!room.players.size) rooms.delete(room.name);
}
function sendRoomBundle(c){const room=c.room;send(c.ws,"welcome",{id:c.id,room:room.name,tick:serverTick,serverTime:now(),worldRevision:room.world.revision,worldName:room.worldName,seed:room.seed||"ADVANCED",mode:c.mode,playerMode:c.mode,permissions:c.permissions,isHost:!!c.isHost,inviteCode:room.inviteCode||null,players:roomSnapshot(room)});sendInventory(c);send(c.ws,"mobSnapshot",{serverTime:now(),mobs:[...room.mobs.values()].filter(m=>!m.dead).map(mobState)});send(c.ws,"projectileSnapshot",{serverTime:now(),projectiles:[...room.projectiles.values()].filter(p=>!p.dead).map(projectileState)});send(c.ws,"dropSnapshot",{drops:[...room.drops.values()].filter(d=>!d.dead)});send(c.ws,"worldState",{revision:room.world.revision,edits:[...room.world.edits].map(([key,blockId])=>({key,blockId}))});}
function handleInviteCreate(c,p){
  const code=makeInviteCode(); const roomName="invite_"+code; const room=getRoom(roomName); room.inviteCode=code;room.worldName=String(p?.worldName||"Thế giới mới").slice(0,32);room.defaultMode=normalizeMode(p?.mode);room.defaultPermissions=cleanPermissions(DEFAULT_PERMISSIONS);room.pvp=true;room.hostId=c.id;inviteRooms.set(code,roomName);
  leaveRoom(c); c.room=room;room.players.add(c);c.isHost=true;c.mode=room.defaultMode;c.permissions={...DEFAULT_PERMISSIONS};c.playerKey=String(p?.playerKey||c.playerKey||c.id).slice(0,128);
  sendRoomBundle(c);send(c.ws,"inviteCreated",{code,room:room.name,worldName:room.worldName,mode:room.defaultMode});send(c.ws,"inviteState",{code,worldName:room.worldName,members:roomSnapshot(room)});
}
function handleInviteJoin(c,p){
  const code=String(p?.code||"").toUpperCase();const roomName=inviteRooms.get(code);if(!roomName)return send(c.ws,"inviteReject",{reason:"INVALID_CODE"});const room=getRoom(roomName);if(room.players.size>=MAX_PLAYERS_PER_ROOM)return send(c.ws,"inviteReject",{reason:"ROOM_FULL"});
  leaveRoom(c);c.room=room;room.players.add(c);c.isHost=false;c.mode=room.defaultMode;c.permissions=cleanPermissions(room.defaultPermissions);c.playerKey=String(p?.playerKey||c.playerKey||c.id).slice(0,128);
  sendRoomBundle(c);send(c.ws,"inviteAccepted",{code,room:room.name,worldName:room.worldName,mode:room.defaultMode,playerMode:c.mode,permissions:c.permissions});broadcast(room,"inviteState",{code,worldName:room.worldName,members:roomSnapshot(room)});
}
function handlePlayerSettings(c,p){if(!c.room)return;const mode=normalizeMode(p?.mode);c.mode=mode;send(c.ws,"permissionChanged",{playerId:c.id,mode:c.mode,permissions:c.permissions});broadcast(c.room,"snapshot",{tick:serverTick,serverTime:now(),players:roomSnapshot(c.room)});}
function handleRoomSettings(c,p){if(!c.room||!c.isHost)return;const room=c.room;room.defaultMode=normalizeMode(p?.mode||room.defaultMode);room.defaultPermissions=cleanPermissions(p?.permissions||room.defaultPermissions);room.pvp=p?.pvp!=="off";for(const target of room.players){if(target===c)continue;target.mode=room.defaultMode;target.permissions={...room.defaultPermissions};send(target.ws,"permissionChanged",{playerId:target.id,mode:target.mode,permissions:target.permissions});}sendMany(room,"roomSettings",{mode:room.defaultMode,permissions:room.defaultPermissions,pvp:room.pvp});}
function handlePermissionUpdate(c,p){if(!c.room||!c.isHost)return;const target=[...c.room.players].find(x=>x.id===String(p?.playerId||""));if(!target)return;target.mode=normalizeMode(p?.mode||target.mode);target.permissions=cleanPermissions(p?.permissions||target.permissions);send(target.ws,"permissionChanged",{playerId:target.id,mode:target.mode,permissions:target.permissions});send(c.ws,"inviteState",{code:c.room.inviteCode||null,worldName:c.room.worldName,members:roomSnapshot(c.room)});broadcast(c.room,"snapshot",{tick:serverTick,serverTime:now(),players:roomSnapshot(c.room)});}

function handleJoin(c,payload) {
  leaveRoom(c);
  const name=String(payload?.room||"default").trim().slice(0,32)||"default";
  const room=getRoom(name);
  if(room.players.size>=MAX_PLAYERS_PER_ROOM){ send(c.ws,"serverError",{code:"ROOM_FULL",message:"Room is full"}); c.ws.close(1008,"room full"); return; }
  c.room=room; room.players.add(c); c.isHost=room.hostId===c.id; c.mode=normalizeMode(payload?.mode||room.defaultMode); c.permissions=cleanPermissions(payload?.permissions||room.defaultPermissions);
  c.playerKey=String(payload?.playerKey||c.playerKey||c.id).slice(0,128);
  if(persisted.players[c.playerKey]?.inventory) c.inventory=persisted.players[c.playerKey].inventory;
  if(!c.inventory) c.inventory=makeInventory(); c.inventoryRevision=0;
  sendRoomBundle(c); broadcast(room,"snapshot",{tick:serverTick,serverTime:now(),players:roomSnapshot(room)},c);
}
function handleInput(c,p) {
  if(!c.room) return;
  c.input.forward=clamp(finite(p?.forward),-MAX_INPUT,MAX_INPUT);
  c.input.right=clamp(finite(p?.right),-MAX_INPUT,MAX_INPUT);
  c.input.jump=!!p?.jump;
  c.yaw=finite(p?.yaw,c.yaw);
  c.yaw=((c.yaw+Math.PI)%(Math.PI*2)+Math.PI)%(Math.PI*2)-Math.PI;
  c.pitch=clamp(finite(p?.pitch,c.pitch),-Math.PI/2,Math.PI/2);
  const dim=String(p?.dimension||c.dimension||"main");
  if(dim==="main" || dim==="war" || dim==="serpent_void") c.dimension=(dim==="serpent_void"?"war":dim);
}
function collidesBody(room,c,x,y,z){
  if(c.dimension !== "main") return false;
  const minX=Math.floor(x-PLAYER_HALF), maxX=Math.floor(x+PLAYER_HALF);
  const minY=Math.floor(y), maxY=Math.floor(y+PLAYER_HEIGHT-0.001);
  const minZ=Math.floor(z-PLAYER_HALF), maxZ=Math.floor(z+PLAYER_HALF);
  for(let bx=minX;bx<=maxX;bx++) for(let by=minY;by<=maxY;by++) for(let bz=minZ;bz<=maxZ;bz++){
    if(getAuthoritativeBlock(room,bx,by,bz,c.dimension)!==0) return true;
  }
  return false;
}
function moveAxis(room,c,axis,amount){
  if(!amount) return;
  const nx=axis==="x"?c.x+amount:c.x, ny=axis==="y"?c.y+amount:c.y, nz=axis==="z"?c.z+amount:c.z;
  if(!collidesBody(room,c,nx,ny,nz)){c.x=nx;c.y=ny;c.z=nz;return;}
  // Small step-up for horizontal movement over low blocks.
  if(axis!=="y" && c.grounded){
    const sy=ny+STEP_HEIGHT;
    if(!collidesBody(room,c,nx,sy,nz)){c.x=nx;c.y=sy;c.z=nz;return;}
  }
  if(axis==="x") c.vx=0;
  if(axis==="z") c.vz=0;
  if(axis==="y") c.vy=0;
}
function tickPlayer(c) {
  const i=c.input; const len=Math.hypot(i.forward,i.right); let f=i.forward,r=i.right;
  if(len>1){f/=len;r/=len;}
  const sin=Math.sin(c.yaw),cos=Math.cos(c.yaw);
  const tx=(sin*f+cos*r)*MAX_SPEED, tz=(-cos*f+sin*r)*MAX_SPEED;
  const step=ACCEL*DT;
  c.vx+=clamp(tx-c.vx,-step,step); c.vz+=clamp(tz-c.vz,-step,step);
  if(Math.abs(f)<.01&&Math.abs(r)<.01){const fr=Math.min(1,FRICTION*DT);c.vx*=1-fr;c.vz*=1-fr;}
  if(i.jump&&c.grounded){c.vy=JUMP_SPEED;c.grounded=false;} i.jump=false;
  c.vy-=GRAVITY*DT;
  c.grounded=false;
  moveAxis(c.room,c,c.vx*DT,"x");
  moveAxis(c.room,c,c.vz*DT,"z");
  const oldY=c.y;
  moveAxis(c.room,c,c.vy*DT,"y");
  if(c.y===oldY && c.vy<=0) c.grounded=true;
  if(c.y<0){c.y=0;c.vy=0;c.grounded=true;}
  if(c.y>MAX_Y){c.y=MAX_Y;c.vy=0;} if(c.y<MIN_Y){c.y=MIN_Y;c.vy=0;}
  const h=Math.hypot(c.vx,c.vz); if(h>MAX_SPEED){const k=MAX_SPEED/h;c.vx*=k;c.vz*=k;}
}
function validCoords(p){return Number.isInteger(p.x)&&Number.isInteger(p.y)&&Number.isInteger(p.z)&&p.y>=0&&p.y<WORLD_HEIGHT;}
function inReach(c,x,y,z){return Math.hypot(x-c.x,(y+0.5)-(c.y+0.9),z-c.z)<=MAX_INTERACTION_DISTANCE;}
function handleBlockRequest(c,p) {
  if(!c.room||!p||!validCoords(p)) return send(c.ws,"blockReject",{requestId:p?.requestId||null,reason:"INVALID_COORDS"});
  const x=int(p.x),y=int(p.y),z=int(p.z),newId=int(p.newId),oldId=int(p.oldId),dimension=String(p.dimension||c.dimension||"main");
  if(dimension!==c.dimension) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"WRONG_DIMENSION"});
  if(!VALID_BLOCKS.has(newId)||!VALID_BLOCKS.has(oldId)) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"INVALID_BLOCK"});
  if(newId===0 && (c.mode==="observer" || c.permissions.break===false)) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"NO_BREAK_PERMISSION"});
  if(newId!==0 && (c.mode==="observer" || c.permissions.place===false)) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"NO_PLACE_PERMISSION"});
  if(!inReach(c,x,y,z)) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"OUT_OF_REACH"});
  const current=getAuthoritativeBlock(c.room,x,y,z,dimension);
  if(current!==oldId) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"STALE_BLOCK",x,y,z,current});
  if(oldId===5&&newId===0) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"ETERNAL_BLOCK"});
  if(newId!==0 && current!==0) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"OCCUPIED"});
  if(newId!==0 && Math.hypot(x-c.x,y-c.y,z-c.z)<1.15) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"PLAYER_OVERLAP"});
  const itemId=String(p.itemId||"");
  if(newId!==0 && c.mode!=="free"){
    if(!VALID_ITEM_IDS.has(itemId)||!hasItem(c.inventory,itemId,1)) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"ITEM_MISSING"});
    if(!removeItem(c.inventory,itemId,1)) return send(c.ws,"blockReject",{requestId:p.requestId,reason:"ITEM_MISSING"});
  }
  setAuthoritativeBlock(c.room,x,y,z,newId);
  const change={revision:c.room.world.revision,x,y,z,blockId:newId,oldBlockId:oldId,dimension,requestId:p.requestId||null,authorId:c.id};
  broadcast(c.room,"blockDelta",change);
  send(c.ws,"blockAccepted",change);
  if(newId!==0 && c.mode!=="free") invChanged(c);
}
function handleChunkRequest(c,p) {
  if(!c.room) return;
  const cx=int(p?.cx),cz=int(p?.cz),dimension=String(p?.dimension||c.dimension||"main");
  if(Math.abs(cx)>100000||Math.abs(cz)>100000||dimension!==c.dimension) return;
  send(c.ws,"chunkState",{cx,cz,dimension,revision:c.room.world.revision,edits:editsForChunk(c.room,cx,cz,dimension)});
}

wss.on("connection",ws=>{
  const c={ws,id:crypto.randomUUID(),playerKey:null,room:null,isHost:false,mode:"survival",permissions:{...DEFAULT_PERMISSIONS},x:16,y:20.5,z:16,vx:0,vy:0,vz:0,yaw:0,pitch:-.22,hp:60,dimension:"main",grounded:false,input:{forward:0,right:0,jump:false},inventory:makeInventory(),inventoryRevision:0,lastPacket:now(),lastAttack:0};
  ws.on("message",raw=>{
    if(raw.length>16*1024)return;
    let msg;try{msg=JSON.parse(raw.toString());}catch{return;}
    if(!msg||typeof msg.type!=="string")return;c.lastPacket=now();
    switch(msg.type){case"join":handleJoin(c,msg.payload);break;case"inviteCreate":handleInviteCreate(c,msg.payload);break;case"inviteJoin":handleInviteJoin(c,msg.payload);break;case"playerSettings":handlePlayerSettings(c,msg.payload);break;case"roomSettings":handleRoomSettings(c,msg.payload);break;case"permissionUpdate":handlePermissionUpdate(c,msg.payload);break;case"input":handleInput(c,msg.payload);break;case"blockRequest":handleBlockRequest(c,msg.payload);break;case"inventoryRequest":handleInventoryRequest(c,msg.payload);break;case"attackRequest":handleAttackRequest(c,msg.payload);break;case"mobAttackRequest":handleMobAttack(c,msg.payload);break;case"skillRequest":handleSkillRequest(c,msg.payload);break;case"dropPickup":handleDropPickup(c,msg.payload);break;case"chunkRequest":handleChunkRequest(c,msg.payload);break;case"ping":send(ws,"pong",{clientTime:finite(msg.payload?.clientTime),serverTime:now(),tick:serverTick});break;case"leave":leaveRoom(c);break;default:break;}
  });
  ws.on("close",()=>leaveRoom(c));ws.on("error",()=>leaveRoom(c));
});

setInterval(()=>{serverTick++;for(const room of rooms.values()){for(const c of room.players)tickPlayer(c);tickMobs(room);tickProjectiles(room);tickSkills(room,now());const snapshot={tick:serverTick,serverTime:now(),players:roomSnapshot(room)};for(const c of room.players)send(c.ws,"snapshot",snapshot);if(serverTick%4===0)mobBroadcast(room);if(serverTick%2===0)projectileBroadcast(room);if(serverTick%10===0)sendMany(room,"dropSnapshot",{drops:[...room.drops.values()].filter(d=>!d.dead)});}},1000/TICK_RATE);
console.log(`Advanced Voxel authoritative multiplayer server listening on :${PORT} (${TICK_RATE} tick/s)`);
