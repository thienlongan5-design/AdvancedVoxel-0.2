"use strict";
/* Advanced Voxel - real multiplayer runtime, Phase 1.
 * Keeps gameplay local while making player state server-authoritative.
 * No Web Worker is used.
 */
(function () {
  const RT = {
    enabled: false,
    remote: new Map(),
    remoteMobs: new Map(),
    remoteProjectiles: new Map(),
    inputAccumulator: 0,
    snapshotAccumulator: 0,
    sendRate: 1 / 20,
    interpolation: 0.12,
    statusEl: null,
    lastServerTick: 0,
    serverOffset: 0
  };

  function safeNumber(v, fallback = 0) {
    return Number.isFinite(Number(v)) ? Number(v) : fallback;
  }

  function makeRemote(id) {
    const root = new THREE.Group();
    root.name = "RemotePlayer_" + id;

    const bodyMat = new THREE.MeshStandardMaterial({ color: 0x4e78a8, roughness: 0.78, metalness: 0.08 });
    const skinMat = new THREE.MeshStandardMaterial({ color: 0xb9c7d2, roughness: 0.85 });
    const darkMat = new THREE.MeshStandardMaterial({ color: 0x263445, roughness: 0.9 });

    const body = new THREE.Mesh(new THREE.BoxGeometry(0.62, 0.88, 0.34), bodyMat);
    body.position.y = 1.0;
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.48, 0.42), skinMat);
    head.position.y = 1.72;
    const armL = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.78, 0.22), bodyMat);
    armL.position.set(-0.42, 1.02, 0);
    const armR = armL.clone();
    armR.position.x = 0.42;
    const legL = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.78, 0.25), darkMat);
    legL.position.set(-0.18, 0.39, 0);
    const legR = legL.clone();
    legR.position.x = 0.18;

    root.add(body, head, armL, armR, legL, legR);
    root.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });

    const labelCanvas = document.createElement("canvas");
    labelCanvas.width = 256; labelCanvas.height = 64;
    const ctx = labelCanvas.getContext("2d");
    ctx.fillStyle = "rgba(10,16,24,.82)";
    ctx.fillRect(2, 2, 252, 60);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 26px sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(id.slice(0, 12), 128, 32);
    const tex = new THREE.CanvasTexture(labelCanvas);
    tex.minFilter = THREE.LinearFilter;
    const label = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
    label.scale.set(1.55, 0.39, 1);
    label.position.y = 2.35;
    root.add(label);

    root.userData.net = {
      id,
      target: new THREE.Vector3(),
      targetYaw: 0,
      dimension: "main",
      hp: 60,
      lastUpdate: performance.now()
    };

    if (typeof GAME !== "undefined" && GAME.scene) GAME.scene.add(root);
    return root;
  }

  function removeRemote(id) {
    const root = RT.remote.get(id);
    if (!root) return;
    if (root.parent) root.parent.remove(root);
    root.traverse(o => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) {
        const mats = Array.isArray(o.material) ? o.material : [o.material];
        mats.forEach(m => { if (m.map) m.map.dispose(); m.dispose(); });
      }
    });
    RT.remote.delete(id);
  }

  function ensureStatus() {
    if (RT.statusEl) return RT.statusEl;
    const el = document.createElement("div");
    el.id = "multiplayerStatus";
    el.textContent = "MP: offline";
    Object.assign(el.style, {
      position: "fixed", top: "8px", left: "50%", transform: "translateX(-50%)",
      zIndex: "9999", padding: "5px 9px", borderRadius: "8px",
      background: "rgba(5,10,18,.72)", color: "#d8e8ff", font: "600 11px sans-serif",
      pointerEvents: "none", display: "none"
    });
    document.body.appendChild(el);
    RT.statusEl = el;
    return el;
  }

  function setStatus(text, visible = true) {
    const el = ensureStatus();
    el.textContent = text;
    el.style.display = visible ? "block" : "none";
  }

  function localState() {
    const p = typeof PLAYER !== "undefined" ? PLAYER.player : null;
    if (!p) return null;
    return {
      x: safeNumber(p.position.x), y: safeNumber(p.position.y), z: safeNumber(p.position.z),
      yaw: safeNumber(p.yaw), pitch: safeNumber(p.pitch),
      vx: safeNumber(p.velocity.x), vy: safeNumber(p.velocity.y), vz: safeNumber(p.velocity.z),
      hp: safeNumber(p.health, 60), dimension: typeof GAME !== "undefined" ? (GAME.dimension || "main") : "main"
    };
  }

  function sendInput() {
    if (!NETWORK.client.connected) return;
    const p = typeof PLAYER !== "undefined" ? PLAYER.player : null;
    if (!p) return;
    const s = localState();
    if (!s) return;
    NETWORK.send("input", {
      forward: safeNumber(p.input.forward),
      right: safeNumber(p.input.right),
      jump: !!p.input.jump,
      yaw: s.yaw,
      pitch: s.pitch,
      dimension: s.dimension,
      // These are hints only. Server does not trust them for authority.
      clientX: s.x, clientY: s.y, clientZ: s.z
    });
  }

  function applyServerLocal(s) {
    const p = typeof PLAYER !== "undefined" ? PLAYER.player : null;
    if (!p || !s) return;
    const sx = safeNumber(s.x), sy = safeNumber(s.y), sz = safeNumber(s.z);
    const dx = sx - p.position.x, dy = sy - p.position.y, dz = sz - p.position.z;
    const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
    // Small errors are smoothed; larger corrections are applied immediately.
    if (dist > 1.5) {
      p.position.set(sx, sy, sz);
      p.velocity.set(safeNumber(s.vx), safeNumber(s.vy), safeNumber(s.vz));
    } else {
      p.position.x += dx * 0.35;
      p.position.y += dy * 0.35;
      p.position.z += dz * 0.35;
    }
    if (Number.isFinite(Number(s.yaw))) p.yaw = Number(s.yaw);
    if (Number.isFinite(Number(s.hp))) p.health = Math.max(0, Number(s.hp));
  }

  function onSnapshot(msg) {
    const payload = msg.payload || {};
    RT.lastServerTick = safeNumber(payload.tick, RT.lastServerTick);
    if (payload.serverTime) RT.serverOffset = safeNumber(payload.serverTime) - Date.now();

    const selfId = NETWORK.client.id;
    const players = Array.isArray(payload.players) ? payload.players : [];
    const seen = new Set();

    for (const s of players) {
      if (!s || !s.id) continue;
      if (s.id === selfId) { applyServerLocal(s); if(s.mode&&typeof GAME!=="undefined"){GAME.playerMode=String(s.mode);GAME.permissions=s.permissions||GAME.permissions;GAME.isHost=!!s.isHost;window.GAME_MODE=GAME.playerMode;} continue; }
      if (s.dimension && typeof GAME !== "undefined" && s.dimension !== (GAME.dimension || "main")) {
        removeRemote(s.id);
        continue;
      }
      seen.add(s.id);
      let root = RT.remote.get(s.id);
      if (!root) { root = makeRemote(s.id); RT.remote.set(s.id, root); }
      const net = root.userData.net;
      net.target.set(safeNumber(s.x), safeNumber(s.y), safeNumber(s.z));
      net.targetYaw = safeNumber(s.yaw);
      net.dimension = s.dimension || "main";
      net.hp = safeNumber(s.hp, 60);
      net.lastUpdate = performance.now();
    }

    for (const id of RT.remote.keys()) if (!seen.has(id)) removeRemote(id);
  }

  function onWelcome(msg) {
    NETWORK.client.id = msg.payload?.id || NETWORK.client.id;
    const wp=msg.payload||{};
    if(wp.mode){window.GAME_MODE=String(wp.mode);if(typeof GAME!=="undefined"){GAME.playerMode=String(wp.mode);GAME.isHost=!!wp.isHost;GAME.permissions=wp.permissions||GAME.permissions;}}
    if(wp.inviteCode){try{localStorage.setItem("advanced_voxel_invite_code",wp.inviteCode)}catch(e){}}
    const players = Array.isArray(msg.payload?.players) ? msg.payload.players : [];
    onSnapshot({ payload: { players, tick: 0, serverTime: Date.now() } });
    setStatus("MP: connected", true);
  }

  function onLeft(msg) { removeRemote(msg.payload?.id); }
  function applyBlockChange(change) {
    if (!change || typeof WORLD === "undefined" || !WORLD.setBlock) return;
    const x = safeNumber(change.x), y = safeNumber(change.y), z = safeNumber(change.z);
    const id = safeNumber(change.blockId);
    if (change.dimension && typeof GAME !== "undefined" && change.dimension !== (GAME.dimension || "main")) return;
    const current = WORLD.getBlock ? WORLD.getBlock(x,y,z) : null;
    if (current !== id) WORLD.setBlock(x,y,z,id);
    if (NETWORK.blockSync?.pending && change.requestId) NETWORK.blockSync.pending.delete(change.requestId);
  }

  function onWorldState(msg) {
    const edits = Array.isArray(msg.payload?.edits) ? msg.payload.edits : [];
    for (const e of edits) {
      const parts = String(e.key || "").split(",").map(Number);
      if (parts.length !== 3 || !parts.every(Number.isFinite)) continue;
      if (typeof WORLD !== "undefined" && WORLD.setBlock) WORLD.setBlock(parts[0],parts[1],parts[2],safeNumber(e.blockId));
    }
  }

  function onBlockDelta(msg) { applyBlockChange(msg.payload || {}); }

  function onBlockReject(msg) {
    const p = msg.payload || {};
    const pending = NETWORK.blockSync?.pending?.get(p.requestId);
    if (!pending) return;
    NETWORK.blockSync.pending.delete(p.requestId);
    if (typeof WORLD !== "undefined" && WORLD.setBlock) WORLD.setBlock(pending.x,pending.y,pending.z,pending.oldId);
    setStatus("MP: block rejected", true);
    setTimeout(() => { if (NETWORK.client.connected) setStatus("MP: connected", true); }, 900);
  }

  function onBlockAccepted(msg) {
    const p = msg.payload || {};
    if (NETWORK.blockSync?.pending && p.requestId) NETWORK.blockSync.pending.delete(p.requestId);
  }

  function onChunkState(msg) {
    const p = msg.payload || {};
    for (const e of (p.edits || [])) if (typeof WORLD !== "undefined" && WORLD.setBlock) WORLD.setBlock(e.x,e.y,e.z,safeNumber(e.blockId));
  }

  function onInventoryState(msg) {
    const p = msg.payload || {};
    if (typeof GAME === "undefined") return;
    if (Array.isArray(p.slots)) GAME.inventoryStacks = p.slots.map(st => ({ id: st?.id || null, count: Math.max(0, safeNumber(st?.count, 0)) }));
    if (Array.isArray(p.hotbar)) GAME.hotbarItems = p.hotbar.slice(0, 12);
    while (GAME.hotbarItems.length < 12) GAME.hotbarItems.push(null);
    if (Number.isInteger(Number(p.selectedSlot))) GAME.selectedSlot = Math.max(0, Math.min(11, Number(p.selectedSlot)));
    GAME.serverEquipment = p.equipment || GAME.serverEquipment || {head:null,chest:null,legs:null,feet:null,shield:null,weapon:null};
    if (typeof syncInventoryTotalFromStacks === "function") syncInventoryTotalFromStacks();
    if (typeof ensureInventoryStacks === "function") ensureInventoryStacks();
    if (typeof updateHotbar === "function") updateHotbar();
    if (typeof updateInventoryUI === "function") updateInventoryUI();
    if (typeof renderInventoryHotbar === "function") renderInventoryHotbar();
    const id = GAME.hotbarItems[GAME.selectedSlot] || null;
    if (typeof PLAYER !== "undefined" && PLAYER?.updateHeldItem) PLAYER.updateHeldItem(id);
  }

  function onInventoryReject(msg) {
    const p = msg.payload || {};
    if (NETWORK.inventorySync?.pending && p.requestId) NETWORK.inventorySync.pending.delete(p.requestId);
    setStatus("MP: inventory rejected", true);
    setTimeout(() => { if (NETWORK.client.connected) setStatus("MP: connected", true); }, 900);
  }


  function updateRemote(dt) {
    const alpha = 1 - Math.pow(0.0001, Math.min(0.05, Math.max(0, dt)) / Math.max(0.01, RT.interpolation));
    for (const root of RT.remote.values()) {
      const net = root.userData.net;
      root.position.lerp(net.target, alpha);
      let d = net.targetYaw - root.rotation.y;
      while (d > Math.PI) d -= Math.PI * 2;
      while (d < -Math.PI) d += Math.PI * 2;
      root.rotation.y += d * alpha;
    }
  }

  RT.getCrosshairRemoteTarget = function(maxDistance=5){
    if(!RT.enabled || !NETWORK.client.connected) return null;
    const cam=typeof GAME!=="undefined"?GAME.camera:null; if(!cam) return null;
    const ray=new THREE.Raycaster(); ray.setFromCamera(new THREE.Vector2(0,0),cam);
    let best=null,bestD=Infinity;
    for(const [id,root] of RT.remote){
      if(!root?.visible) continue;
      const meshes=[]; root.traverse(o=>{if(o.isMesh)meshes.push(o);});
      const hits=ray.intersectObjects(meshes,false);
      if(!hits.length) continue;
      const d=hits[0].distance; if(d<=maxDistance&&d<bestD){bestD=d;best={id,root,distance:d};}
    }
    return best;
  };

  function onCombatHit(msg){
    const p=msg.payload||{};
    if(NETWORK.combatSync?.pending&&p.requestId)NETWORK.combatSync.pending.delete(p.requestId);
    const localId=NETWORK.client.id;
    if(p.targetId===localId && typeof PLAYER!=="undefined"&&PLAYER.player){ PLAYER.player.health=Math.max(0,safeNumber(p.targetHp,PLAYER.player.health)); }
    const root=RT.remote.get(p.targetId); if(root&&root.userData?.net)root.userData.net.hp=Math.max(0,safeNumber(p.targetHp,root.userData.net.hp));
    if(typeof showUnifiedActionFeedback==="function"&&p.attackerId===localId)showUnifiedActionFeedback("attack");
  }
  function onCombatReject(msg){ const p=msg.payload||{}; if(NETWORK.combatSync?.pending&&p.requestId)NETWORK.combatSync.pending.delete(p.requestId); }
  function onPlayerRespawn(msg){ const p=msg.payload||{}; if(p.id===NETWORK.client.id&&typeof PLAYER!=="undefined"&&PLAYER.player){PLAYER.player.position.set(16,20.5,16);PLAYER.player.health=60;} const root=RT.remote.get(p.id); if(root){root.position.set(16,20.5,16);if(root.userData?.net)root.userData.net.target.set(16,20.5,16);}}


  function makeNetworkMob(m){
    const root=new THREE.Group(); root.name="NetworkMob_"+m.id; root.userData.networkMob=true; root.userData.net={id:m.id,type:m.type,hp:m.hp,maxHp:m.maxHp,target:new THREE.Vector3(m.x,m.y,m.z),dimension:m.dimension};
    const color=m.type==="warden"?0x3fa7ad:0x17121c; const mesh=new THREE.Mesh(new THREE.BoxGeometry(0.9,1.8,0.9),new THREE.MeshStandardMaterial({color,roughness:.75,metalness:.15})); mesh.position.y=.9; root.add(mesh);
    if(typeof ModelLoader!=="undefined") ModelLoader.load(m.type==="warden"?"./assets/models/Titanium_Warden.glb":"./assets/models/Titan_Ravage.glb",(obj)=>{ if(!root.parent)return; while(root.children.length)root.remove(root.children[0]); const box=new THREE.Box3().setFromObject(obj),size=new THREE.Vector3();box.getSize(size);if(size.y>.001)obj.scale.multiplyScalar(2/size.y);obj.position.y=-(new THREE.Box3().setFromObject(obj).min.y);root.add(obj); });
    root.position.set(m.x,m.y,m.z); GAME.scene.add(root); return root;
  }
  function onMobSnapshot(msg){
    const list=Array.isArray(msg.payload?.mobs)?msg.payload.mobs:[], seen=new Set();
    for(const m of list){seen.add(m.id);let root=RT.remoteMobs?.get(m.id);if(!root){RT.remoteMobs=RT.remoteMobs||new Map();root=makeNetworkMob(m);RT.remoteMobs.set(m.id,root);}const n=root.userData.net;n.target.set(safeNumber(m.x),safeNumber(m.y),safeNumber(m.z));n.hp=safeNumber(m.hp);n.maxHp=safeNumber(m.maxHp,100);n.dimension=m.dimension;root.visible=n.dimension===(GAME.dimension||"main");}
    if(RT.remoteMobs)for(const [id,root] of RT.remoteMobs)if(!seen.has(id)){GAME.scene.remove(root);RT.remoteMobs.delete(id);}
  }
  function onMobDamage(msg){const p=msg.payload||{},root=RT.remoteMobs?.get(p.mobId);if(root?.userData?.net)root.userData.net.hp=safeNumber(p.hp,root.userData.net.hp);}
  function onMobDeath(msg){const id=msg.payload?.mobId,root=RT.remoteMobs?.get(id);if(root){GAME.scene.remove(root);RT.remoteMobs.delete(id);}}
  function onProjectileSnapshot(msg){
    const list=Array.isArray(msg.payload?.projectiles)?msg.payload.projectiles:[]; const seen=new Set(); RT.remoteProjectiles=RT.remoteProjectiles||new Map();
    for(const p of list){seen.add(p.id);let o=RT.remoteProjectiles.get(p.id);if(!o){o=new THREE.Mesh(new THREE.SphereGeometry(.13,8,8),new THREE.MeshBasicMaterial({color:p.color||0xffffff}));GAME.scene.add(o);RT.remoteProjectiles.set(p.id,o);}o.position.set(safeNumber(p.x),safeNumber(p.y),safeNumber(p.z));}
    for(const [id,o] of RT.remoteProjectiles)if(!seen.has(id)){GAME.scene.remove(o);o.geometry.dispose();o.material.dispose();RT.remoteProjectiles.delete(id);}
  }

  function onDropSnapshot(msg){ RT.remoteDrops=RT.remoteDrops||new Map(); const list=Array.isArray(msg.payload?.drops)?msg.payload.drops:[],seen=new Set(); for(const d of list){seen.add(d.id);let o=RT.remoteDrops.get(d.id);if(!o){o=new THREE.Mesh(new THREE.BoxGeometry(.22,.22,.22),new THREE.MeshStandardMaterial({color:0xe3b84a,emissive:0x4b2f08,emissiveIntensity:.7}));GAME.scene.add(o);RT.remoteDrops.set(d.id,o);}o.position.set(safeNumber(d.x),safeNumber(d.y+.2),safeNumber(d.z));o.userData.drop=d;} for(const [id,o] of RT.remoteDrops)if(!seen.has(id)){GAME.scene.remove(o);RT.remoteDrops.delete(id);}}

  function onSkillCast(msg){const p=msg.payload||{}; if(NETWORK.skillSync?.pending&&p.requestId)NETWORK.skillSync.pending.delete(p.requestId); if(typeof showUnifiedActionFeedback==="function")showUnifiedActionFeedback("attack");}
  function onSkillReject(msg){const p=msg.payload||{};if(NETWORK.skillSync?.pending&&p.requestId)NETWORK.skillSync.pending.delete(p.requestId);}

  RT.connect = function (url, room) {
    ensureStatus();
    NETWORK.on("welcome", onWelcome);
    NETWORK.on("snapshot", onSnapshot);
    NETWORK.on("playerLeft", onLeft);
    NETWORK.on("worldState", onWorldState);
    NETWORK.on("blockDelta", onBlockDelta);
    NETWORK.on("blockReject", onBlockReject);
    NETWORK.on("blockAccepted", onBlockAccepted);
    NETWORK.on("chunkState", onChunkState);
    NETWORK.on("inventoryState", onInventoryState);
    NETWORK.on("inventoryReject", onInventoryReject);
    NETWORK.on("combatHit", onCombatHit);
    NETWORK.on("combatReject", onCombatReject);
    NETWORK.on("playerRespawn", onPlayerRespawn);
    NETWORK.on("mobSnapshot", onMobSnapshot);
    NETWORK.on("mobDamage", onMobDamage);
    NETWORK.on("mobDeath", onMobDeath);
    NETWORK.on("projectileSnapshot", onProjectileSnapshot);
    NETWORK.on("skillCast", onSkillCast);
    NETWORK.on("skillReject", onSkillReject);
    NETWORK.on("dropSnapshot", onDropSnapshot);
    NETWORK.on("serverError", m => setStatus("MP: " + (m.payload?.message || "server error"), true));
    const ok = NETWORK.connect(url, room || "default");
    if (ok) setStatus("MP: connecting...", true);
    return ok;
  };

  RT.update = function (dt) {
    if (!RT.enabled || !NETWORK.client.connected) return;
    RT.inputAccumulator += Math.min(0.05, Math.max(0, dt));
    if (RT.inputAccumulator >= RT.sendRate) {
      RT.inputAccumulator = 0;
      sendInput();
    }
    updateRemote(dt);
    if (RT.remoteMobs) { for (const root of RT.remoteMobs.values()) { const n=root.userData.net; root.position.lerp(n.target, 0.22); } }
  };

  RT.enable = function (url, room) {
    RT.enabled = true;
    return RT.connect(url, room);
  };

  window.MULTIPLAYER = RT;
})();
