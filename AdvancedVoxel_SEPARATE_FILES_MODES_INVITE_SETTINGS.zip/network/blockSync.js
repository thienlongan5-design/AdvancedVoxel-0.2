"use strict";
window.NETWORK=window.NETWORK||{};
NETWORK.blockSync={
  pending:new Map(),
  request(x,y,z,oldId,newId,dimension,itemId=null){
    const requestId=`b${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
    const packet={requestId,x,y,z,oldId,newId,dimension:dimension||"main",itemId:itemId||null};
    this.pending.set(requestId,packet);
    const ok=NETWORK.send("blockRequest",packet);
    if(!ok)this.pending.delete(requestId);
    return ok;
  },
  requestChunk(cx,cz,dimension){return NETWORK.send("chunkRequest",{cx,cz,dimension:dimension||"main"});}
};
