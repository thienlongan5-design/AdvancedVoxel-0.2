"use strict";
window.NETWORK=window.NETWORK||{};
NETWORK.combatSync={
  pending:new Map(),
  attack(targetId,weaponId){
    const requestId=`a${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
    const packet={requestId,targetId:String(targetId),weaponId:String(weaponId||"")};
    this.pending.set(requestId,packet);
    const ok=NETWORK.send("attackRequest",packet);
    if(!ok)this.pending.delete(requestId);
    return ok;
  }
};
