"use strict";window.NETWORK=window.NETWORK||{};NETWORK.playerSync={enabled:true};
