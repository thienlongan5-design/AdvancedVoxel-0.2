"use strict";
window.NETWORK = window.NETWORK || {};
NETWORK.client = {
  socket: null,
  connected: false,
  connecting: false,
  id: null,
  room: null,
  seq: 0,
  handlers: {},
  url: null,
  reconnectTimer: null,
  reconnectAttempts: 0,
  heartbeatTimer: null,
  maxBufferedBytes: 256 * 1024,
  playerKey: localStorage.getItem("advanced_voxel_player_key") || (crypto.randomUUID ? crypto.randomUUID() : "p_"+Math.random().toString(36).slice(2))
};
try { localStorage.setItem("advanced_voxel_player_key", NETWORK.client.playerKey); } catch (_) {}

NETWORK.on = function (type, fn) {
  if (typeof fn !== "function") return;
  (this.client.handlers[type] ||= []).push(fn);
};

NETWORK.emit = function (msg) {
  const list = this.client.handlers[msg.type] || [];
  for (const fn of list) { try { fn(msg); } catch (e) { console.error("NETWORK handler", msg.type, e); } }
};

NETWORK.connect = function (url, room = "default") {
  const c = this.client;
  c.url = url; c.room = String(room || "default").slice(0, 32);
  if (c.connected || c.connecting) return true;
  try {
    c.connecting = true;
    const ws = new WebSocket(c.url);
    c.socket = ws;
    ws.onopen = () => {
      c.connected = true; c.connecting = false; c.reconnectAttempts = 0;
      this.send("join", { room: c.room, playerKey: c.playerKey });
      clearInterval(c.heartbeatTimer);
      c.heartbeatTimer = setInterval(() => this.send("ping", { clientTime: Date.now() }), 5000);
    };
    ws.onmessage = e => {
      let m; try { m = JSON.parse(e.data); } catch (_) { return; }
      if (!m || typeof m.type !== "string") return;
      if (m.type === "welcome" && m.payload?.id) c.id = m.payload.id;
      this.emit(m);
    };
    ws.onerror = () => this.emit({ type: "serverError", payload: { message: "connection error" } });
    ws.onclose = () => {
      c.connected = false; c.connecting = false; clearInterval(c.heartbeatTimer);
      this.emit({ type: "serverError", payload: { message: "disconnected" } });
      if (c.url && c.reconnectAttempts < 5) {
        const delay = Math.min(8000, 600 * Math.pow(2, c.reconnectAttempts++));
        clearTimeout(c.reconnectTimer);
        c.reconnectTimer = setTimeout(() => this.connect(c.url, c.room), delay);
      }
    };
    return true;
  } catch (e) {
    c.connected = false; c.connecting = false;
    return false;
  }
};

NETWORK.send = function (type, payload = {}) {
  const c = this.client;
  if (!c.socket || c.socket.readyState !== WebSocket.OPEN) return false;
  if (c.socket.bufferedAmount > c.maxBufferedBytes) return false;
  const packet = { v: window.NETWORK_PROTOCOL?.version || 2, type, seq: ++c.seq, t: Date.now(), payload };
  try { c.socket.send(JSON.stringify(packet)); return true; } catch (_) { return false; }
};
NETWORK.input = p => NETWORK.send("input", p);
NETWORK.interaction = p => NETWORK.send("interaction", p);
NETWORK.disconnect = function () {
  const c = this.client;
  clearTimeout(c.reconnectTimer); clearInterval(c.heartbeatTimer);
  c.url = null;
  if (c.socket) try { c.socket.close(1000, "client disconnect"); } catch (_) {}
};
