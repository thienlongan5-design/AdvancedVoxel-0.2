"use strict";window.NETWORK=window.NETWORK||{};NETWORK.snapshotManager={enabled:true};
