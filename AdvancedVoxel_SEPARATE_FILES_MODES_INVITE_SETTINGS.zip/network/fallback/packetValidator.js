"use strict";window.NETWORK_FALLBACK=window.NETWORK_FALLBACK||{};NETWORK_FALLBACK.packetValidator={enabled:true};
