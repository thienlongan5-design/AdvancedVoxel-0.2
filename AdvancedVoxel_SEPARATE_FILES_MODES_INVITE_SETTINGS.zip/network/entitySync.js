"use strict";window.NETWORK=window.NETWORK||{};NETWORK.entitySync={enabled:true};
