"use strict";window.NETWORK=window.NETWORK||{};NETWORK.connectionManager={enabled:true};
