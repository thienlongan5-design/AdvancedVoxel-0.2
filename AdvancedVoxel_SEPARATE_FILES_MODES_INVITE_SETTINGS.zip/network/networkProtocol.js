"use strict";
window.NETWORK_PROTOCOL = {
  version: 2,
  tickRate: 20,
  snapshotRate: 20,
  types: [
    "join", "leave", "input", "snapshot", "event", "error", "ping", "pong",
    "welcome", "playerLeft", "inviteCreate", "inviteJoin", "inviteCreated", "inviteAccepted", "inviteReject", "inviteState", "permissionUpdate", "permissionChanged", "playerSettings", "roomSettings", "serverError", "worldState", "blockRequest", "blockAccepted", "blockReject", "blockDelta", "chunkRequest", "chunkState", "inventoryRequest", "inventoryState", "inventoryReject", "attackRequest", "combatHit", "combatReject", "playerRespawn", "mobSnapshot", "mobDamage", "mobDeath", "projectileSnapshot", "dropDelta", "dropSnapshot", "skillRequest", "skillCast", "skillAccepted", "skillReject", "damageEvent"
  ],
  clientToServer: { join: 1, inviteCreate:1, inviteJoin:1, permissionUpdate:1, playerSettings:1, roomSettings:1, input: 1, leave: 1, ping: 1, blockRequest: 1, chunkRequest: 1, inventoryRequest: 1, attackRequest: 1, mobAttackRequest: 1, skillRequest: 1, dropPickup: 1 },
  serverToClient: { welcome: 1, inviteCreated:1, inviteAccepted:1, inviteReject:1, inviteState:1, permissionChanged:1, roomSettings:1, snapshot: 1, playerLeft: 1, pong: 1, serverError: 1, worldState: 1, blockAccepted: 1, blockReject: 1, blockDelta: 1, chunkState: 1, inventoryState: 1, inventoryReject: 1, combatHit: 1, combatReject: 1, playerRespawn: 1, mobSnapshot: 1, mobDamage: 1, mobDeath: 1, projectileSnapshot: 1, dropDelta: 1, dropSnapshot: 1, skillCast: 1, skillAccepted: 1, skillReject: 1, damageEvent: 1 }
};
