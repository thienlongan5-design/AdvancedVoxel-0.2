"use strict";
window.NETWORK = window.NETWORK || {};
NETWORK.inventorySync = {
  pending: new Map(),
  request(action, payload = {}) {
    const requestId = `i${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
    const packet = Object.assign({requestId, action}, payload);
    this.pending.set(requestId, packet);
    const ok = NETWORK.send("inventoryRequest", packet);
    if (!ok) this.pending.delete(requestId);
    return ok;
  },
  move(from,to){ return this.request("move",{from,to}); },
  split(from,to,amount){ return this.request("split",{from,to,amount}); },
  takeOne(from){ return this.request("takeOne",{from}); },
  assignHotbar(id,slot){ return this.request("assignHotbar",{id,slot}); },
  clearHotbar(slot){ return this.request("clearHotbar",{slot}); },
  selectHotbar(slot){ return this.request("selectHotbar",{slot}); },
  equip(id,slot){ return this.request("equip",{id,slot}); },
  unequip(slot){ return this.request("unequip",{slot}); },
  consume(id,count=1){ return this.request("consume",{id,count}); },
  add(id,count=1){ return this.request("add",{id,count}); },
  craft(recipeId){ return this.request("craft",{recipeId}); }
};
