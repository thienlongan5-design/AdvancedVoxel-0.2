"use strict";window.NETWORK=window.NETWORK||{};NETWORK.serverAuthority={enabled:true};
