"use strict";window.NETWORK=window.NETWORK||{};NETWORK.chunkSync={enabled:true};
