"use strict";window.NETWORK=window.NETWORK||{};NETWORK.interpolation={enabled:true};
