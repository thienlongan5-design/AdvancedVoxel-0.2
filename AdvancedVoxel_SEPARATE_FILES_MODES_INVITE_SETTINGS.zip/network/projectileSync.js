"use strict";window.NETWORK=window.NETWORK||{};NETWORK.projectileSync={enabled:true,byId:new Map()};
