"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.weatherSync={enabled:true};
