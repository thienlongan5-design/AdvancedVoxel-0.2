"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.tickManager={enabled:true};
