"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.worldState={enabled:true};
