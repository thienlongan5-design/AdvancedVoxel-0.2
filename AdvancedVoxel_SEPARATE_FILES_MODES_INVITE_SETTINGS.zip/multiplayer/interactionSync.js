"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.interactionSync={enabled:true};
