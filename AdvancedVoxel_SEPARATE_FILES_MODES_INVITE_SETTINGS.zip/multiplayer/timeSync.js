"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.timeSync={enabled:true};
