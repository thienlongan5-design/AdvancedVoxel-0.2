"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.eventSync={enabled:true};
