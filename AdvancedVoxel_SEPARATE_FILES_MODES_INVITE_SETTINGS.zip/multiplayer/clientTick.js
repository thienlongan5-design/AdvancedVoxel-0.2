"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.clientTick={enabled:true};
