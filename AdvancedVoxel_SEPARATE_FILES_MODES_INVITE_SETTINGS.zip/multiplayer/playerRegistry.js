"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.playerRegistry={enabled:true};
