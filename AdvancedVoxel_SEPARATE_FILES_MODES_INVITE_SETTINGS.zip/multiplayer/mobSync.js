"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.mobSync={enabled:true};
