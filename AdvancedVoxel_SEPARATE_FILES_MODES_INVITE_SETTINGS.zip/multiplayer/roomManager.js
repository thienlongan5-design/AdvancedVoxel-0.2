"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.roomManager={enabled:true};
