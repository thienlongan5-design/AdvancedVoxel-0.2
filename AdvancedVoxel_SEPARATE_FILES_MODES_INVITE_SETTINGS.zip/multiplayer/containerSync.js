"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.containerSync={enabled:true};
