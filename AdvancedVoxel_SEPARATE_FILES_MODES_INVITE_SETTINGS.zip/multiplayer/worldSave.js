"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.worldSave={enabled:true};
