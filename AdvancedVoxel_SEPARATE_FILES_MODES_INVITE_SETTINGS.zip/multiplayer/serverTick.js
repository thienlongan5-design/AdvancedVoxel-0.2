"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.serverTick={enabled:true};
