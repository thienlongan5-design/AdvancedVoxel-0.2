"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.spawnManager={enabled:true};
