"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.dimensionSync={enabled:true};
