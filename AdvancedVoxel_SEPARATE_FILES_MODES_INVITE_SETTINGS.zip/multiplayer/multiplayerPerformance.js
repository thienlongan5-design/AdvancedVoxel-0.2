"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.multiplayerPerformance={enabled:true};
