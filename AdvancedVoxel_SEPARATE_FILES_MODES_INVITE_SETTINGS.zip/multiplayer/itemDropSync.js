"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.itemDropSync={enabled:true};
