"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.sessionManager={enabled:true};
