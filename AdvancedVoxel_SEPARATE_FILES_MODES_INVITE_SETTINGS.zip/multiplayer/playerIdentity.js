"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.playerIdentity={enabled:true};
