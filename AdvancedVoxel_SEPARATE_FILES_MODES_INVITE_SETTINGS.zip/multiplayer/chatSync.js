"use strict";window.MULTIPLAYER=window.MULTIPLAYER||{};MULTIPLAYER.chatSync={enabled:true};
